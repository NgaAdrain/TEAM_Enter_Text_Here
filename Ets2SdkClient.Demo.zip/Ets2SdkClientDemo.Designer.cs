﻿namespace Ets2SdkClient.Demo
{
    partial class Ets2SdkClientDemo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Ets2SdkClientDemo));
            this.telemetryInfo = new System.Windows.Forms.TabControl();
            this.tabAbout = new System.Windows.Forms.TabPage();
            this.lbGeneral = new System.Windows.Forms.RichTextBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.lblDemo = new System.Windows.Forms.Label();
            this.TB_record = new System.Windows.Forms.TextBox();
            this.telemetryInfo.SuspendLayout();
            this.tabAbout.SuspendLayout();
            this.SuspendLayout();
            // 
            // telemetryInfo
            // 
            this.telemetryInfo.Controls.Add(this.tabAbout);
            this.telemetryInfo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.telemetryInfo.Location = new System.Drawing.Point(0, 0);
            this.telemetryInfo.Name = "telemetryInfo";
            this.telemetryInfo.SelectedIndex = 0;
            this.telemetryInfo.Size = new System.Drawing.Size(694, 573);
            this.telemetryInfo.TabIndex = 0;
            // 
            // tabAbout
            // 
            this.tabAbout.Controls.Add(this.TB_record);
            this.tabAbout.Controls.Add(this.lbGeneral);
            this.tabAbout.Controls.Add(this.richTextBox1);
            this.tabAbout.Controls.Add(this.lblDemo);
            this.tabAbout.Location = new System.Drawing.Point(4, 22);
            this.tabAbout.Name = "tabAbout";
            this.tabAbout.Padding = new System.Windows.Forms.Padding(3);
            this.tabAbout.Size = new System.Drawing.Size(686, 547);
            this.tabAbout.TabIndex = 0;
            this.tabAbout.Text = "About";
            this.tabAbout.UseVisualStyleBackColor = true;
            // 
            // lbGeneral
            // 
            this.lbGeneral.Location = new System.Drawing.Point(23, 194);
            this.lbGeneral.Name = "lbGeneral";
            this.lbGeneral.Size = new System.Drawing.Size(640, 225);
            this.lbGeneral.TabIndex = 2;
            this.lbGeneral.Text = "";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(23, 56);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(640, 113);
            this.richTextBox1.TabIndex = 1;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // lblDemo
            // 
            this.lblDemo.AutoSize = true;
            this.lblDemo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDemo.Location = new System.Drawing.Point(154, 30);
            this.lblDemo.Name = "lblDemo";
            this.lblDemo.Size = new System.Drawing.Size(336, 25);
            this.lblDemo.TabIndex = 0;
            this.lblDemo.Text = "ETS2 SDK Telemetry C# Demo";
            // 
            // TB_record
            // 
            this.TB_record.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.TB_record.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TB_record.Location = new System.Drawing.Point(531, 492);
            this.TB_record.Name = "TB_record";
            this.TB_record.ReadOnly = true;
            this.TB_record.Size = new System.Drawing.Size(132, 20);
            this.TB_record.TabIndex = 3;
            this.TB_record.Text = "RECORD";
            this.TB_record.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Ets2SdkClientDemo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(694, 573);
            this.Controls.Add(this.telemetryInfo);
            this.Name = "Ets2SdkClientDemo";
            this.Text = "Ets2SdkClientDemo 1.4.0";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Ets2SdkClientDemo_FormClosed);
            this.Load += new System.EventHandler(this.Ets2SdkClientDemo_Load);
            this.telemetryInfo.ResumeLayout(false);
            this.tabAbout.ResumeLayout(false);
            this.tabAbout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl telemetryInfo;
        private System.Windows.Forms.TabPage tabAbout;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Label lblDemo;
        private System.Windows.Forms.RichTextBox lbGeneral;
        private System.Windows.Forms.TextBox TB_record;
    }
}

