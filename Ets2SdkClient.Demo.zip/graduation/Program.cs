﻿
using System;
using System.Windows.Forms;
using System.Net.Sockets;

namespace Ets2SdkClient.Demo
{
    public class Program
    {

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Korean kor = Korean.Instance();
            LogItem log = LogItem.Instance();

            Console.WriteLine("Running Application");
            Application.Run(new Ets2SdkClientDemo());


        }

    }
}
