﻿
using System.Collections.Generic;

namespace Ets2SdkClient.Demo
{
    class Korean
    {
        private static Korean instance = null;
        private Dictionary<string, string> typeName = null;

        public Dictionary<string, string> TypeName { get => typeName; set => typeName = value; }

        private Korean()
        {
            typeName = new Dictionary<string, string>();

            typeName.Add("Drivetrain", "드라이브트레인");
            typeName.Add("TruckOdometer", "오도미터(적산거리)");
            typeName.Add("EngineEnabled", "시동 상태");
            typeName.Add("GearDashboard", "대시보드의 기어 상태");
            typeName.Add("EngineRpm", "엔진 RPM");
            typeName.Add("EngineRpmMax", "최대 엔진 RPM");

            typeName.Add("Fuel", "연료 잔여량");
            typeName.Add("FuelMax", "연료 최대량");
            typeName.Add("FuelRange", "연료 주행가능거리");
            typeName.Add("FuelAvgConsumption", "평균 연료 소모");
            typeName.Add("CruiseControl", "크루즈 컨트롤");
            typeName.Add("CruiseControlSpeed", "크루즈 속도");
            typeName.Add("CruiseControlSpeedKmh", "크루즈 속도(Km/h)");
            typeName.Add("CruiseControlSpeedMph", "크루즈 속도(Mp/h)");


            typeName.Add("Physics", "물리 데이터"); //
            typeName.Add("Speed", "속도");
            typeName.Add("SpeedKmh", "시속(Km/h)");
            typeName.Add("SpeedMph", "시속(Mp/h)");
            typeName.Add("AccelerationX", "X축 가속도");
            typeName.Add("AccelerationY", "Y축 가속도");
            typeName.Add("AccelerationZ", "Z축 가속도");
            typeName.Add("CoordinateX", "좌표 X 값");
            typeName.Add("CoordinateY", "좌표 Y 값");
            typeName.Add("CoordinateZ", "좌표 Z 값");
            typeName.Add("RotationX", "회전 X 값");
            typeName.Add("RotationY", "회전 Y 값");
            typeName.Add("RotationZ", "회전 Z 값");

            typeName.Add("Controls", "운전자 조작"); //
            typeName.Add("UserSteer", "컨트롤러 조향각");
            typeName.Add("UserThrottle", "컨트롤러 액셀");
            typeName.Add("UserBrake", "컨트롤러 브레이크");
            typeName.Add("UserClutch", "컨트롤러 클러치");
            typeName.Add("GameSteer", "게임 조향각");
            typeName.Add("GameThrottle", "게임 액셀");
            typeName.Add("GameBrake", "게임 브레이크");
            typeName.Add("GameClutch", "게임 클러치");

            typeName.Add("Lights", "라이트"); //
            typeName.Add("BlinkerLeftActive", "좌측 깜빡이 상태");
            typeName.Add("BlinkerRightActive", "우측 깜빡이 상태");
            typeName.Add("BlinkerLeftOn", "좌측 깜빡이 활성화");
            typeName.Add("BlinkerRightOn", "우측 깜빡이 활성화");
            typeName.Add("BrakeLight", "브레이크등");
            typeName.Add("Beacon", "경광등");
            typeName.Add("ReverseLight", "후진(R) 라이트");
            typeName.Add("ParkingLights", "차폭등(미등)");
            typeName.Add("LowBeams", "전조등");
            typeName.Add("HighBeams", "상향등");

            typeName.Add("Damage", "차량 파손"); //
            typeName.Add("WearEnigne", "엔진 파손도");
            typeName.Add("WearTransmission", "미션 파손도");
            typeName.Add("WearCabin", "실내(캐빈) 파손도");
            typeName.Add("WearChassis", "섀시 파손도");
            typeName.Add("WearWheels", "바퀴 파손도");
            typeName.Add("WearTrailer", "트레일러(트럭) 파손도");
        }

        public static Korean Instance()
        {
            //if (instance == null)
                instance = new Korean();
            return instance;
        }

        //public Dictionary<string, string> GetDictionary()
        //{
        //    return typeName;
        //}
    }
}