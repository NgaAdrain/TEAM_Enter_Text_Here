﻿using System;
using System.Windows.Forms;
using System.Diagnostics;

namespace Ets2SdkClient.Demo
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Korean kor = Korean.Instance();
            LogItem log = LogItem.Instance();
            Debug.WriteLine("start program");
            Application.Run(new Ets2SdkClientDemo());
        }
    }
}
