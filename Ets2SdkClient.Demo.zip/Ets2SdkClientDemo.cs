﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Ets2SdkClient.Demo
{
    public partial class Ets2SdkClientDemo : Form
    {
        public Ets2SdkTelemetry Telemetry;

        public Dictionary<string, string> typeName; // 한글화를 위한 딕셔너리 변수 선언
        uint preTime = 0;                           // 이전 시간을 담은 변수

        public Dictionary<string, float> lastData;  // 로깅을 위한 최근 차량정보 값
        LoggerState loggingState;
        GatheringData logger;

        public Ets2SdkClientDemo()
        {
            InitializeComponent();
            TB_record.BackColor = SystemColors.Window;

            Telemetry = new Ets2SdkTelemetry();
            Telemetry.Data += Telemetry_Data;

            Telemetry.JobFinished += TelemetryOnJobFinished;
            Telemetry.JobStarted += TelemetryOnJobStarted;

            if (Telemetry.Error != null)
            {
                lbGeneral.Text =
                    "General info:\r\nFailed to open memory map " + Telemetry.Map +
                        " - on some systems you need to run the client (this app) with elevated permissions, because e.g. you're running Steam/ETS2 with elevated permissions as well. .NET reported the following Exception:\r\n" +
                        Telemetry.Error.Message + "\r\n\r\nStacktrace:\r\n" + Telemetry.Error.StackTrace;
            }

            /*
             * modified by ysjeon
             * date         : 2018.07.13
             */
            typeName = Korean.Instance().TypeName;
            lastData = LogItem.Instance().Item;
            loggingState = LoggerState.STOP;
            logger = new GatheringData();
        }

        private void TelemetryOnJobFinished(object sender, EventArgs args)
        {
        }

        private void TelemetryOnJobStarted(object sender, EventArgs e)
        {
        }

        private void Telemetry_Data(Ets2Telemetry data, bool updated)
        {
            try
            {
                if (this.InvokeRequired)
                {
                    this.Invoke(new TelemetryData(Telemetry_Data), new object[2] { data, updated });
                    return;
                }

                lbGeneral.Text = "General info:\r\n SDK Version: " + data.Version.SdkPlugin + "\r\n Reported game Version: " +
                                 data.Version.Ets2Major + "." + data.Version.Ets2Minor + "\r\n\r\nTruck: " + data.Truck + " (" + data.TruckId + ")\r\nManufacturer: " + data.Manufacturer + "(" + data.ManufacturerId + ")" +
                                 "\r\nGame Timestamp: " + data.Time + "\r\nPaused? " + data.Paused;

                // Do some magic trickery to display ALL info:
                var grps = new object[]
                       {
                           data.Drivetrain, data.Physics, data.Controls, data.Axilliary, data.Damage, data.Lights, data.Job
                       };

                foreach (var grp in grps)
                {
                    // Find the right tab page:
                    var grpName = grp.GetType().Name;

                    if (grpName.StartsWith("_"))
                        grpName = grpName.Substring(1);

                    // Add
                    string value;
                    if (typeName.TryGetValue(grpName, out value))
                    {
                        grpName = typeName[grpName];
                    }
                    //

                    var tabPage = default(TabPage);
                    var tabFound = false;

                    for (int k = 0; k < telemetryInfo.TabCount; k++)
                    {
                        if (telemetryInfo.TabPages[k].Text == grpName)
                        {
                            tabPage = telemetryInfo.TabPages[k];
                            tabFound = true;
                        }
                    }

                    if (!tabFound)
                    {
                        tabPage = new CustomTabPage(grpName);
                        telemetryInfo.TabPages.Add(tabPage);
                    }

                    // All properties;
                    var props = grp.GetType().GetProperties().OrderBy(x => x.Name);
                    var labels = new StringBuilder();
                    var vals = new StringBuilder();
                    foreach (var prop in props)
                    {
                        ///*
                        // * modified by ysjeon
                        // * date         : 2018.07.11
                        // */
                        string temp;                                        // 임시 변수
                        if (typeName.TryGetValue(prop.Name, out temp))      // Name을 기반으로 temp를 획득 가능하다면
                        {
                            labels.AppendLine(typeName[prop.Name] + ":");   // 라벨의 Text를 한글로 얻어옴
                        }
                        else
                        {
                            labels.AppendLine(prop.Name + ":");
                        }

                        // 차량정보 값 갱신
                        if (lastData.ContainsKey(prop.Name))
                        {
                            object values = prop.GetValue(grp, null);
                            if (values is float)
                                lastData[prop.Name] = (float)values;
                        }

                        // 시간이 갱신될 경우
                        if (preTime < data.Time && preTime > 0)
                        {
                            if (loggingState == LoggerState.STOP && lastData["UserClutch"] == 1.0)
                            {
                                loggingState = LoggerState.READY;
                            }
                            else if (loggingState == LoggerState.READY && lastData["UserClutch"] == 0.0)
                            {
                                loggingState = LoggerState.WORKING;
                                TB_record.ForeColor = Color.Red;
                                TB_record.BackColor = SystemColors.Window;
                                System.Diagnostics.Debug.WriteLine("gathering start");
                                logger.BeginGathering();
                            }
                            else if (loggingState == LoggerState.WORKING && lastData["UserClutch"] == 1.0)
                            {
                                loggingState = LoggerState.STOPPING;
                            }
                            else if (loggingState == LoggerState.STOPPING && lastData["UserClutch"] == 0.0)
                            {
                                loggingState = LoggerState.STOP;
                                TB_record.ForeColor = Color.Black;
                                TB_record.BackColor = SystemColors.Window;
                                logger.EndGathering();
                            }

                            // 차량정보 기록
                            if (loggingState == LoggerState.WORKING)
                            {
                                logger.WriteData(data.Time,data.Lights.BlinkerLeftOn, data.Lights.BlinkerRightOn);
                            }
                        }
                        preTime = data.Time;    // 시간 갱신
                        /********************************************************************************************************************/

                        object val = prop.GetValue(grp, null);
                        if (val is float[])
                        {
                            vals.AppendLine(string.Join(", ", (val as float[]).Select(x=> x.ToString("0.000"))));
                        }
                        else
                        {
                            vals.AppendLine(val.ToString());
                        }
                    }

                    tabPage.Controls.Clear();
                    var lbl1 = new Label { Location = new Point(3, 3), Size = new Size(200, tabPage.Height - 6) };
                    var lbl2 = new Label { Location = new Point(203, 3), Size = new Size(1000, tabPage.Height - 6) };
                    lbl1.Text = labels.ToString();
                    lbl2.Text = vals.ToString();
                    lbl2.AutoSize = false;
                    tabPage.Controls.Add(lbl1);
                    tabPage.Controls.Add(lbl2);
                }
            }
            catch
            {
            }
        }

        private void Ets2SdkClientDemo_Load(object sender, EventArgs e)
        {
            //logger.BeginGathering();
        }

        private void Ets2SdkClientDemo_FormClosed(object sender, FormClosedEventArgs e)
        {
            logger.EndGathering();
        }
    }

    enum LoggerState
    {
        STOP,
        STOPPING,
        READY,
        WORKING
    }
}