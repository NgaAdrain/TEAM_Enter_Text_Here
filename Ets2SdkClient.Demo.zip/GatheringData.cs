﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;

namespace Ets2SdkClient.Demo
{
    class GatheringData
    {
        FileStream logFile;                 // 데이터 로깅을 위한 스트림라이터
        Simlog.Builder logBuilder;
        List<Process> logProcess;
        string logStoragePath;
        string driverRecordPath;
        string gameRecordPath;
        string recDriverArg;
        string recGameArg;

        public GatheringData()
        {
            logFile = null;
            logBuilder = Simlog.CreateBuilder();
            logProcess = new List<Process>();
            // Run enviorment
            logStoragePath = Environment.CurrentDirectory + @"\..\Stuff\logs\";
            driverRecordPath = Environment.CurrentDirectory + @"\..\Stuff\record_driver\";
            gameRecordPath = Environment.CurrentDirectory + @"\..\Stuff\record_game\";
            recDriverArg = "-f dshow -i video=" + "\"c922 Pro Stream Webcam\""
                            + ":audio=" + "\"마이크(C922 Pro Stream Webcam)\""
                            //+ " -c:v libx264 -c:a aac -g 15 -preset ultrafast ";
                            + " -c:v h264_nvenc -c:a aac -g 15 -preset llhp ";

            recGameArg = "-y -f gdigrab -framerate 30 -i desktop "
                        + "-c:v hevc_nvenc -r 30 -preset llhq "
                        + "-vsync 1 -s 1920x1080 "
                        + "-pix_fmt yuv420p ";
           
            /*
            recGameArg = "-y -f gdigrab -framerate 30 -i desktop "
                        + "-c:v hevc_qsv -r 30 -preset veryfast "
                        + "-vsync 1 -s 1920x1080 "
                        + "-tune zerolatency "
                        + "-pix_fmt yuv420p ";

           
            recGameArg = "-y -f gdigrab -framerate 30 -i desktop " 
                            + "-c:v hevc_nvenc -r 30 -preset llhq "
                            + "-vsync 1 -s 1920x1080 "
                            + "-pix_fmt yuv420p ";
                            */
            /*
            recGameArg = "-y -f gdigrab -framerate 30 -i title=" + "\"Euro Truck Simulator 2\" "
                            + "-c:v hevc_nvenc -r 30 -preset llhp -pix_fmt yuv420p ";
                            */
        }

        public void BeginGathering()
        {
            logBuilder.Clear();
            string fnamePrefix = DateTime.Now.ToString("yyyyMMdd_HHmmss");
            // record driver video
            string args = recDriverArg + '"' + driverRecordPath + fnamePrefix + "_driver.mp4" + '"';
            BeginRecord(args);
            // record game video
            args = recGameArg + '"' + gameRecordPath + fnamePrefix + "_ingame.mp4" + '"';
            BeginRecord(args);
            // create file for recording game information
            args = logStoragePath + fnamePrefix + ".dat";
            logFile = new FileStream(args, FileMode.CreateNew);
        }

        public void EndGathering()
        {
            if (logFile == null || logProcess.Count == 0)
                return;
            StopRecord();
            Simlog logSet = logBuilder.Build();
            logSet.WriteTo(logFile);
            logFile.Close();
            logBuilder.Clear();
        }

        public void WriteData(uint inGameTime)
        {
            Drivetrain.Builder drivetrain = Drivetrain.CreateBuilder();
            drivetrain.SetTruckOdometer(LogItem.Instance().Item["TruckOdometer"]);
            drivetrain.SetGearDashboard(LogItem.Instance().Item["GearDashboard"]);
            drivetrain.SetEngineRpm(LogItem.Instance().Item["EngineRpm"]);
            drivetrain.SetFuel(LogItem.Instance().Item["Fuel"]);
            drivetrain.SetFuelAvgConsumption(LogItem.Instance().Item["FuelAvgConsumption"]);

            Physics.Builder physics = Physics.CreateBuilder();
            physics.SetSpeedKmh(LogItem.Instance().Item["SpeedKmh"]);
            physics.SetAccelerationX(LogItem.Instance().Item["AccelerationX"]);
            physics.SetAccelerationY(LogItem.Instance().Item["AccelerationY"]);
            physics.SetAccelerationZ(LogItem.Instance().Item["AccelerationZ"]);
            physics.SetCoordinateX(LogItem.Instance().Item["CoordinateX"]);
            physics.SetCoordinateY(LogItem.Instance().Item["CoordinateY"]);
            physics.SetCoordinateZ(LogItem.Instance().Item["CoordinateZ"]);
            physics.SetRotationX(LogItem.Instance().Item["RotationX"]);
            physics.SetRotationY(LogItem.Instance().Item["RotationY"]);
            physics.SetRotationZ(LogItem.Instance().Item["RotationZ"]);

            Controls.Builder controls = Controls.CreateBuilder();
            controls.SetUserSteer(LogItem.Instance().Item["UserSteer"]);
            controls.SetUserThrottle(LogItem.Instance().Item["UserThrottle"]);
            controls.SetUserBrake(LogItem.Instance().Item["UserBrake"]);

            Lights.Builder lights = Lights.CreateBuilder();
            lights.SetBlinkerLeftOn(LogItem.Instance().Item["BlinkerLeftOn"]);
            lights.SetBlinkerRightOn(LogItem.Instance().Item["BlinkerRightOn"]);

            DrivingInformation.Builder newInfo = DrivingInformation.CreateBuilder();
            newInfo.SetTimestamp(DateTime.Now.ToString("yyyyMMdd_HHmmss"));
            newInfo.SetInGameTime(inGameTime);
            newInfo.SetDrivetrain(drivetrain);
            newInfo.SetPhysics(physics);
            newInfo.SetControls(controls);
            newInfo.SetLights(lights);

            DrivingInformation info = newInfo.Build();
            logBuilder.AddInfo(info);

            System.Diagnostics.Debug.WriteLine("aaa");
        }

        private void BeginRecord(string args)
        {
            string fullpath = Environment.CurrentDirectory + @"\..\Stuff\ffmpeg\ffmpeg.exe";
            Process ffmpeg = new Process
            {
                StartInfo =
                {
                    FileName = @"..\Stuff\ffmpeg\ffmpeg.exe",
                    //Arguments = @"-list_devices true -f dshow -i dummy",
                    Arguments = args,
                    UseShellExecute = false,
                    RedirectStandardInput = true,
                    //RedirectStandardError = true,
                    //RedirectStandardOutput = true,
                    //WindowStyle = ProcessWindowStyle.Hidden,
                    //CreateNoWindow = true
                    CreateNoWindow = true
                }
            };
            //ffmpeg.EnableRaisingEvents = true;
            //ffmpeg.OutputDataReceived += (s, e) => Debug.WriteLine(e.Data);
            //ffmpeg.ErrorDataReceived += (s, e) => Debug.WriteLine($@"Error: {e.Data}");
            ffmpeg.Start();
            //ffmpeg.BeginOutputReadLine();
            //ffmpeg.BeginErrorReadLine();
            logProcess.Add(ffmpeg);
        }


        private void StopRecord()
        {
            foreach (var proc in logProcess)
            {
                proc.StandardInput.WriteLine('q');
                proc.WaitForExit();
            }
            logProcess.Clear();

            Process[] processList = Process.GetProcessesByName("ffmpeg");
            foreach (var proc in processList)
            {
                proc.Kill();
            }
        }
    }
}