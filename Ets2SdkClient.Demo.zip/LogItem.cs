﻿
using System.Collections.Generic;

namespace Ets2SdkClient.Demo
{
    class LogItem
    {
        private static LogItem instance = null;
        private Dictionary<string, float> item = null;

        public Dictionary<string, float> Item { get => item; set => item = value; }

        private LogItem(Korean kor)
        {
            item = new Dictionary<string, float>();
            Dictionary<string, string> dic = kor.TypeName;
            foreach (KeyValuePair<string, string> kv in dic)
            {
                item.Add(kv.Key, 0.0f);
            }
        }

        private LogItem()
        {
            item = new Dictionary<string, float>();
            /*
             * Drivetrain
             */ 
            item.Add("TruckOdometer", 0.0f);
            //item.Add("EngineEnabled", 0.0f);
            item.Add("GearDashboard", 0.0f);
            item.Add("EngineRpm", 0.0f);
            //item.Add("EngineRpmMax", 0.0f);
            item.Add("Fuel", 0.0f);
            //item.Add("FuelMax", 0.0f);
            //item.Add("FuelRange", 0.0f);
            item.Add("FuelAvgConsumption", 0.0f);
            //item.Add("CruiseControl", 0.0f);
            //item.Add("CruiseControlSpeed", 0.0f);
            ////item.Add("CruiseControlSpeedKmh", 0.0f);
            //item.Add("CruiseControlSpeedMph", 0.0f);
            /*
             * Physics
             */ 
            //item.Add("Speed", 0.0f);
            item.Add("SpeedKmh", 0.0f);
            //item.Add("SpeedMph", 0.0f);
            item.Add("AccelerationX", 0.0f);
            item.Add("AccelerationY", 0.0f);
            item.Add("AccelerationZ", 0.0f);
            item.Add("CoordinateX", 0.0f);
            item.Add("CoordinateY", 0.0f);
            item.Add("CoordinateZ", 0.0f);
            item.Add("RotationX", 0.0f);
            item.Add("RotationY", 0.0f);
            item.Add("RotationZ", 0.0f);
            /*
             * Controls
             */ 
            item.Add("UserSteer", 0.0f);
            item.Add("UserThrottle", 0.0f);
            item.Add("UserBrake", 0.0f);
            item.Add("UserClutch", 0.0f);
            //item.Add("GameSteer", 0.0f);
            //item.Add("GameThrottle", 0.0f);
            //item.Add("GameBrake", 0.0f);
            //item.Add("GameClutch", 0.0f);
            /*
             * Lights
             */
            //item.Add("BlinkerLeftActive", 0.0f);
            //item.Add("BlinkerRightActive", 0.0f);
            item.Add("BlinkerLeftOn", 0.0f);
            item.Add("BlinkerRightOn", 0.0f);
            //item.Add("BrakeLight", 0.0f);
            //item.Add("Beacon", 0.0f);
            //item.Add("ReverseLight", 0.0f);
            //item.Add("ParkingLights", 0.0f);
            //item.Add("LowBeams", 0.0f);
            //item.Add("HighBeams", 0.0f);
            /*
             * Damage
             */            
            //item.Add("WearEnigne", 0.0f);
            //item.Add("WearTransmission", 0.0f);
            //item.Add("WearCabin", 0.0f);
            //item.Add("WearChassis", 0.0f);
            //item.Add("WearWheels", 0.0f);
            //item.Add("WearTrailer", 0.0f);
        }

        public static LogItem Instance(Korean kor)
        {
            if (instance == null)
                instance = new LogItem(kor);
            return instance;
        }

        public static LogItem Instance()
        {
            if (instance == null)
                instance = new LogItem();
            return instance;
        }

        //public Dictionary<string, float> GetDictionary()
        //{
        //    return item;
        //}
    }
}